#ifndef FULL_ASM
#define FULL_ASM

#include <stdio.h>

#define NUM_MEM_CELLS   (4096)  /* amount of memory cells on the machine */

int assembleFile(char filename[FILENAME_MAX]);

#endif /* FULL_ASM */
