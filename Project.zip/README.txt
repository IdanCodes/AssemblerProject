Semester 2024a - Maman 14 - Final Project
Student ID: 331409326
Student Name: Idan Sahar עידן סהר

-- To Compile the Code:
Run "make".
It will compile all the files inside it, and create a directory called "bin", where all ".o" files will be stored.
The makefile generates a file called "prog" - which is the assembler's executable file.

All the tests are located in the directory "tests".

The main method is located inside main.c.

Note: The makefile also has a target called "force" to force compilation of all the files inside src.
Note: I used an alias which I called "asm" to run the assembler in the error screenshots.